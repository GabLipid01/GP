def calcular_blend_otimo(oleo_base, teor_oleico_desejado):
    return {
        "Óleo base": oleo_base,
        "Teor de ácido oleico desejado": teor_oleico_desejado,
        "Blend final": {
            "Palma": 60,
            "Palmiste": 40
        }
    }