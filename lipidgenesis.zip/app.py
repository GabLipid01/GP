import streamlit as st
from blend_calculator import calcular_blend_otimo
from utils.visualizations import plot_blend_pie, show_pyramid
from utils.export_pdf import exportar_pdf
from data.profiles import FATTY_ACID_PROFILES
from data.sensory_esg_data import dados_sensoriais, dados_esg

st.set_page_config(page_title="LipidGenesis - Blend LG", layout="wide")

st.title("LipidGenesis - Blend LG")
st.markdown("Plataforma inteligente para formulação de blends lipídicos sustentáveis.")

oleo_base = st.selectbox("Selecione o óleo base:", list(FATTY_ACID_PROFILES.keys()))
perfil_desejado = st.slider("Teor desejado de ácido oleico (%)", 0, 100, 45)

resultado = calcular_blend_otimo(oleo_base, perfil_desejado)
st.subheader("Resultado do Blend Ótimo")
st.write(resultado)

plot_blend_pie(resultado)
show_pyramid(resultado)

if st.button("Exportar PDF"):
    exportar_pdf(resultado)